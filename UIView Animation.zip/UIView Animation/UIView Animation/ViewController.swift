//
//  ViewController.swift
//  UIView Animation
//
//  Created by Frank Tellez on 12/14/19.
//  Copyright © 2019 Frank Tellez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

