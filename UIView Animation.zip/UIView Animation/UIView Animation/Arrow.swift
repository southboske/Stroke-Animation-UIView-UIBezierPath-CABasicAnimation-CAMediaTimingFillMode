//
//  Arrow.swift
//  UIView Animation
//
//  Created by Frank Tellez on 12/14/19.
//  Copyright © 2019 Frank Tellez. All rights reserved.
//

import UIKit

class Arrow: UIView {

    var drawingLogo = UIBezierPath()
       
       override func draw(_ rect: CGRect) {
           saint1()
          
           let layer = CAShapeLayer()
           layer.path = drawingLogo.cgPath
           
           layer.strokeEnd = 0
           layer.lineWidth = 3
           layer.strokeColor = UIColor.red.cgColor
           layer.fillColor = UIColor.blue.cgColor
           
           self.layer.addSublayer(layer)
           
           let animation = CABasicAnimation(keyPath: "strokeEnd")
           animation.toValue = 1
           animation.duration = 5
           animation.autoreverses = false
           animation.fillMode = CAMediaTimingFillMode.forwards
           animation.isRemovedOnCompletion = false
           animation.repeatCount = 2
           layer.add(animation, forKey: "line")
           
       }
       
       
       func saint1() {
           
        drawingLogo = UIBezierPath()
        drawingLogo.move(to: .init(x: 213, y: 304))
        drawingLogo.addLine(to: CGPoint(x: 213, y: 600))
        drawingLogo.addLine(to: CGPoint(x: 225, y: 600))
        drawingLogo.addLine(to: CGPoint(x: 225, y: 356))
        drawingLogo.addLine(to: CGPoint(x: 310, y: 445))
        drawingLogo.addLine(to: CGPoint(x: 332, y: 423))
        drawingLogo.addLine(to: CGPoint(x: 213, y: 304))
        
        drawingLogo.addLine(to: CGPoint(x: 200, y: 304))
        drawingLogo.addLine(to: CGPoint(x: 82, y: 423))
        drawingLogo.addLine(to: CGPoint(x: 105, y: 447))
        drawingLogo.addLine(to: CGPoint(x: 191, y: 354))
        drawingLogo.addLine(to: CGPoint(x: 191, y: 600))
        drawingLogo.addLine(to: CGPoint(x: 202, y: 600))
        drawingLogo.addLine(to: CGPoint(x: 202, y: 304))
        
        
        
        

           //drawingLogo.close()
       }
    

}
